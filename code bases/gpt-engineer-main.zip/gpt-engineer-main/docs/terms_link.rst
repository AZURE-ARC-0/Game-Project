.. include:: ../TERMS_OF_USE.md
   :parser: myst_parser.sphinx_
