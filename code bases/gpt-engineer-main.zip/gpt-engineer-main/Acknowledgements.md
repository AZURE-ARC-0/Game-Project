# We thank the following people for inspiration

| Person | Content | File(s) | Source |
|----|---|---|---|
| Paul Gauthier | The prompt for the `improve code` step is strongly based on Paul's prompt in Aider | /preprompts/improve.txt | https://github.com/paul-gauthier/aider/blob/main/aider/coders/editblock_coder.py
