import nextpy as xt

config = xt.Config(
    app_name="portfolio",
)