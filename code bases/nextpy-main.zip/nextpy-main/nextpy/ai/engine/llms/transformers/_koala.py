# This file has been modified by the Nextpy Team in 2023 using AI tools and automation scripts. 
# We have rigorously tested these modifications to ensure reliability and performance. Based on successful test results, we are confident in the quality and stability of these changes.

from ._llama import LLaMA


class Koala(LLaMA):
    """A HuggingFace transformers version of the Koala language model with Engine support."""

    llm_name: str = "koala"

    default_system_prompt = """BEGINNING OF CONVERSATION:"""

    @staticmethod
    def role_start(role):
        if role == "user":
            return "USER: "
        elif role == "assistant":
            return "GPT: "
        else:
            return ""

    @staticmethod
    def role_end(role):
        if role == "user":
            return ""
        elif role == "assistant":
            return "</s>"
        else:
            return ""