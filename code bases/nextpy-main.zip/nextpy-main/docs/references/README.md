# References

- [xt.upload](https://github.com/dot-agent/nextpy/blob/main/docs/references/frontend/components/core/upload_reference.md)

## Pending Review:

- References for other components is currently in progress and will be added soon.

