This is work in progress. Creating modular open.agent version of the SalesGPT repo
source: https://github.com/filip-michalsky/SalesGPT
