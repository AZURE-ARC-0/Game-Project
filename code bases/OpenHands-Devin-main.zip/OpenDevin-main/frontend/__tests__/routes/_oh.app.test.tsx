import { describe, it } from "vitest";

describe("App", () => {
  it.todo("should render");
});
