import { describe, it } from "vitest";

describe("DropdownInput", () => {
  it.todo("should render the input");
  it.todo("should render the placeholder");
  it.todo("should render the dropdown when clicked");
  it.todo("should select an option when clicked");
  it.todo("should filter the options when typing");
});
