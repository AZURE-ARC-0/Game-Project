import { describe, it } from "vitest";

describe("PlayMenuCard", () => {
  it.todo("should render the initial project title");
  it.todo("should be able to edit the project title");
  it.todo("should render the menu list items when clicking the ellipses");
  it.todo("should close the menu list when clicking outside");
});
