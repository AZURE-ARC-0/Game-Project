import { describe, it } from "vitest";

describe("ConnectToGitHubByTokenModal", () => {
  it.todo("should render the form");
  it.todo("should set the token in local storage");
});
