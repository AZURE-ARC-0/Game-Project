export function ContextMenuSeparator() {
  return <div className="w-full h-[1px] bg-[#525252]" />;
}
