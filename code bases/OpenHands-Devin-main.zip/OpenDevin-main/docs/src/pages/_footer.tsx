import React from 'react';
import CustomFooter from '../components/CustomFooter';

export default function Footer() {
  return <CustomFooter />;
}
