---
name: Technical Proposal
about: Propose a new architecture or technology
title: ''
labels: 'proposal'
assignees: ''

---

**Summary**

**Motivation**

**Technical Design**

**Alternatives to Consider**

**Additional context**
