---
name: Feature Request
about: Suggest an idea for OpenHands features
title: ''
labels: 'enhancement'
assignees: ''

---

**What problem or use case are you trying to solve?**

**Describe the UX of the solution you'd like**

**Do you have thoughts on the technical implementation?**

**Describe alternatives you've considered**

**Additional context**
