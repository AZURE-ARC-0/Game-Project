def reverse_string(s):
    return s[::-1]
