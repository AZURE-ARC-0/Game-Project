def to_uppercase(s):
    return s.upper()
