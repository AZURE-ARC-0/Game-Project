#!/bin/bash


python -m optimus1.tests.test_optimus1 minerl.port=9000 evaluate="[0]"