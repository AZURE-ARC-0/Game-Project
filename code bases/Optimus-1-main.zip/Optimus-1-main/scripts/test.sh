#!/bin/bash


python -m optimus1.test_optimus1 server.port=9000 benchmark=diamond