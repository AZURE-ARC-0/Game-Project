#!/bin/bash


CUDA_VISIBLE_DEVICES=0 uvicorn app:app --port 9000