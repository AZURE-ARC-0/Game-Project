import os

# import gym
# Perform the registration.
from gym.envs.registration import register
from collections import OrderedDict

# TOOD: Add fake envs back.
# from minerl.env.recording import MineRLRecorder, MINERL_RECORDING_PATH
