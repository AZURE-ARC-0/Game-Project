# Copyright (c) 2020 All Rights Reserved
# Author: William H. Guss, Brandon Houghton

"""Defines miscellaneous agent handlers"""

# class PauseAction(Handler):
#     def to_string(self):
#         return "pause"

#     @property
#     def xml_element(self) -> str:
#         return "PauseCommand"
