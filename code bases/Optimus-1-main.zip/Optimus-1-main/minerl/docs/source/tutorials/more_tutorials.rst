More Tutorials
======================

Here we aim to collect links to projects done by us and others, which can be helpful for you getting started.

- `MineRL in Colab <https://colab.research.google.com/drive/1ZcXMm2OR82wSAkzptF2yJeoPmN6z60-6?usp=sharing>`_
- `OpenAI VPT in Colab <https://colab.research.google.com/drive/1OYdc4FwmW1nYTHLfCpEHv-hn83euvRdh?usp=sharing>`_
- `MineRL Diamond in Colab <https://colab.research.google.com/drive/1rJ3lGy-bG7kJRe_wYBWg7fjSaD9oOMDw?usp=sharing>`_
- `Tutorials on MineRL BASALT (by mdda) <https://github.com/mdda/DiamondJAX>`_
- `First steps with MineRL (by mdda) <https://www.youtube.com/watch?v=8yIrWcyWGek>`_
- `Installing MineRL using containers (by mdda) <https://www.youtube.com/watch?v=ZkoU9pRyS38>`_
