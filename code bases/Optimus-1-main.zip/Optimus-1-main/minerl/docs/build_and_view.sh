#!/bin/bash
make clean html
open build/html/index.html

