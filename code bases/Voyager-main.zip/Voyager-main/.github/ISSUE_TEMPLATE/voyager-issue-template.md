---
name: Voyager Issue Template
about: Create an issue to Voyager
title: ''
labels: ''
assignees: ''

---

### Before submitting an issue, make sure you read the [FAQ.md](FAQ.md)

### Briefly describe your issue
...
### Please provide your python, nodejs, Minecraft, and Fabric versions here
...
### [If applicable] Please provide the Minefalyer and Minecraft logs, you can find the log under `logs` folder
...
### [If applicable] Please provide the GPT conversations that are printed each round.
...
