---
description: List for all supported customizations 
---
# Supported Customizations 


```mdx-code-block
import DocCardList from '@theme/DocCardList';

<DocCardList />
```