# Plugin

Plugins are the user-defined functions that extend TaskWeaver CodeInterpreter's capabilities. 
More details about plugins can be found in the [Plugin Introduction](../customization/plugin/plugin_intro.md).
In TaskWeaver, the collection of available plugins are attached to the [Conversation](./conversation.md) object.
