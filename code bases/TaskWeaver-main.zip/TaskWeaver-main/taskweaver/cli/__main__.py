from .cli import taskweaver


def main():
    taskweaver()


if __name__ == "__main__":
    main()
