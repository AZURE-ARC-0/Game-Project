python run.py \
    --task crosswords \
    --task_start_index 0 \
    --task_end_index 20 \
    --naive_run \
    --prompt_sample standard \
    --n_generate_sample 10 