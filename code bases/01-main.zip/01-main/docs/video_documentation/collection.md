
## For End Users
[Announcment video](https://www.youtube.com/watch?v=jWr-WeXAdeI)
[Wes Roth](https://www.youtube.com/@WesRoth)

<details>
<summary>Details</summary>

No technical coverage

</details>

---

[Announcment video](https://www.youtube.com/watch?v=JaBFT3fF2fk)
[TheAIGRID](https://www.youtube.com/@TheAiGrid)

<details>
<summary>Details</summary>

[here](https://youtu.be/JaBFT3fF2fk?si=8zPGO-U6WdLNnISw&t=656)
mentions the current lack of windows support

</details>

---

[Announcment video](https://www.youtube.com/watch?v=Q_p82HtBqoc)
[Matt Berman](https://www.youtube.com/@matthew_berman)

<details>
<summary>Details</summary>

[here](https://youtu.be/Q_p82HtBqoc?si=aAxjWZnBdwBbaOUr&t=579)
Berman shows an install of 01 using conda and python 3.9
in.. looks like linux.. shows how to get openai keys.

</details>

---

[Announcment video](https://www.youtube.com/watch?v=q0dJ7T7au2Y)
[WorldofAI](https://www.youtube.com/@intheworldofai)

<details>
<summary>Details</summary>

<!-- Add details here -->

</details>

---

[Breakdown video](https://www.youtube.com/watch?v=W-VwN0n4d9Y)
[Mervin Praison](https://www.youtube.com/@MervinPraison)
<details>
<summary>Details</summary>
- uses conda to install 01 and uses python 3.11 on linux.. maybe mac
- 0:00 Introduction to Open Interpreter
- 0:47 Creating Apps and Summarizing Documents
- 1:20 Image Modifications and Game Creation
- 2:55 Exploratory Data Analysis and Charting
- 4:00 Server Log Analysis
- 5:01 Image and Video Editing
- 6:00 Composing Music with AI
- 7:18 Calendar Management and Email Automation
- 9:01 Integrating with Fast API and LM Studio

</details>

---

[Breakdown video](https://www.youtube.com/watch?v=uyfoHQVgeY0)
[Gary Explains](https://www.youtube.com/@GaryExplains)
<br>for **open interpreter** not **01**
<details>
<summary>Details</summary>
- 3:45 states that it will run on mac/linux and windows and requires python 3.10
</details>

## For Developers
<BR>
Coming soon