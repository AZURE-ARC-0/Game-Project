# STL files

You can find the STL files to 3d print your own 01 light at

- [Thingiverse](https://www.thingiverse.com/thing:6529845)
- [Printables](https://www.printables.com/model/803461-01-light-version-1-the-worlds-first-language-model)
