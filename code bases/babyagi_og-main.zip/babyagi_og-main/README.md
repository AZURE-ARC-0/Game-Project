# babyagi_og
The original BabyAGI, updated with LiteLLM and no vector database reliance (csv instead).

For more information on this, check out (babyagi_archive)[https://github.com/yoheinakajima/babyagi_archive] which is a snapshot of the original BabyAGI repo as of September 2024.
