{: .tip }
In some environments you may get "aider command not found" errors.
You can try `python -m aider` or 
[see here for more info](/docs/troubleshooting/aider-not-found.html).

