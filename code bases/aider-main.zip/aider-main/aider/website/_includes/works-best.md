Aider works best with GPT-4o & Claude 3.5 Sonnet and can 
[connect to almost any LLM](https://aider.chat/docs/llms.html).
