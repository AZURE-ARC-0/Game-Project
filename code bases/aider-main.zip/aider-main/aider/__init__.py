try:
    from aider.__version__ import __version__
except Exception:
    __version__ = "0.64.2.dev"

__all__ = [__version__]
