package com.microsoft.Malmo.Access;

import net.minecraft.util.math.Vec3d;

public interface IMixinMixinVec3drotatePitchLidar {
    public Vec3d rotatePitchLidar(float pitch);
}
