this is the archive for v0 of smol developer, which was the original Modal.com based version that we found (well, knew) had a few issues with reliability and dependency management.

it has been rewritten from scratch in the root folder, but is preserved here for others to easily reference.