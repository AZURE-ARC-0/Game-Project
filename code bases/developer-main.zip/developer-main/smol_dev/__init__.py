from smol_dev.prompts import *
__author__ = "morph"
