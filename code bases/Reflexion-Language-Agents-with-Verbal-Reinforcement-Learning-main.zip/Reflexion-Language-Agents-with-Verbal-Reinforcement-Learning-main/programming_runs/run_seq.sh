./run_reflexion_starchat_multi.sh $1
./run_simple_starchat_multi.sh $1
