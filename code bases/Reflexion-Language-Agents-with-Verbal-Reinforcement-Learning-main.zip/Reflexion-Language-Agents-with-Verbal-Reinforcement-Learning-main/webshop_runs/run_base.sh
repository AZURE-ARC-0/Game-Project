python main.py \
        --num_trials 10 \
        --num_envs 100 \
        --run_name "base_run_logs_3" \
