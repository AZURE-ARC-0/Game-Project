python main.py \
        --num_trials 10 \
        --num_envs 134 \
        --run_name "base_run_logs_gpt_35_turbo" \
        --model "gpt-3.5-turbo"

