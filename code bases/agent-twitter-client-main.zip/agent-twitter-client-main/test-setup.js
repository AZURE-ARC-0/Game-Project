globalThis.PLATFORM_NODE = false;
globalThis.PLATFORM_NODE_JEST = true;
