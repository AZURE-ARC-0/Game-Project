path_dict = {
    "get_cat_manual": "/GetCatManual"
}