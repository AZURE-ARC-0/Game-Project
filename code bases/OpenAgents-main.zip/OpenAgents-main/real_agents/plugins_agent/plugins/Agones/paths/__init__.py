path_dict = {
    "chatgpt_results": "/api/chatgpt"
}