path_dict = {
    "query_magic_box": "/query"
}