path_dict = {
    "recommend_activities": "/ChatPlugin/RecommendActivities/"
}