path_dict = {
    "product_list": "/api/search",
    "stores": "/api/stores"
}