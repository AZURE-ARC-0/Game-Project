path_dict = {
    "sales_tax": "/sales/tax"
}