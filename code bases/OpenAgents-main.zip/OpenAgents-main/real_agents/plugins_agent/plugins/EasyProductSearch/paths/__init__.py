path_dict = {
    "search_items": "/api/search/{username}",
    "travel_search": "/api/travel-search/{username}"
}