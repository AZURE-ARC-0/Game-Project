path_dict = {
    "getStore": "/api/v2/openai/getStore"
}