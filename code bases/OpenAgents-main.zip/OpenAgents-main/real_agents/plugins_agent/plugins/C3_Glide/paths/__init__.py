path_dict = {
    "open_ai_plugin": "/openAIPlugin"
}