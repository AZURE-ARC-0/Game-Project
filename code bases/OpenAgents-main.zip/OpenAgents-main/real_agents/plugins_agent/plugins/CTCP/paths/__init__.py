path_dict = {
    "get_trial": "/trial/{trialID}"
}