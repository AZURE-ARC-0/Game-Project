path_dict = {
    "generate_diagram": "/generate_diagram"
}