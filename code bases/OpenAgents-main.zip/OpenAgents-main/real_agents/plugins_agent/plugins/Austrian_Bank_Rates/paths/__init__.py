path_dict = {
    "account_info": "/api/account",
    "bank_info": "/api/bank",
    "call": "/api/call"
}