path_dict = {
    "art_collection": "/{query}"
}