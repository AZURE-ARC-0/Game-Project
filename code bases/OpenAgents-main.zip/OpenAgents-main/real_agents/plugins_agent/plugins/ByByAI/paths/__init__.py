path_dict = {
    "search_products": "/api/search"
}