path_dict = {
    "datasets": "/api/datasets",
    "get_tables": "/api/datasets/{datasetId}/tables",
    "get_table_schema": "/api/datasets/{datasetId}/tables/{tableId}/schema",
    "query_bigquery": "/api/query",
    "resolve_eth_address_or_ens": "/api/resolve",
}
