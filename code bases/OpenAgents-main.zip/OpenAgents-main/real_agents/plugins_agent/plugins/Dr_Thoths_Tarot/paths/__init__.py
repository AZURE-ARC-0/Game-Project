path_dict = {
    "career": "/career",
    "celtic_cross_prompt": "/celticcross",
    "chakra": "/chakra",
    "drawcard": "/drawcard",
    "favicon": "/favicon.ico",
    "horseshoe": "/horseshoe",
    "occult_card": "/occult_card",
    "pastpresentfuture": "/pastpresentfuture",
    "relationship": "/relationship",
    "three_card_spread": "/threecardspread",
    "yesno_prompt": "/yesno"
}