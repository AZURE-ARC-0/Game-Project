path_dict = {
    "query_github_repository_file_contents": "/api/chatgpt-plugins/askthecode/query",
    "query_github_repository_structure": "/api/chatgpt-plugins/askthecode/structure"
}