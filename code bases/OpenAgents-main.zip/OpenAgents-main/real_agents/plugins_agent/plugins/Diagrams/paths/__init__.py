path_dict = {"render_diagram": "/diagram"}
