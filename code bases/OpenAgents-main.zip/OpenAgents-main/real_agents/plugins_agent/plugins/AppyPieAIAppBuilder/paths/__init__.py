path_dict = {
    "text_to_app": "/v1"
}