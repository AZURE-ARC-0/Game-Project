path_dict = {"apex_map_prediction": "/apex/predict-future-map", "ranked_map": "/apex/ranked-map"}
