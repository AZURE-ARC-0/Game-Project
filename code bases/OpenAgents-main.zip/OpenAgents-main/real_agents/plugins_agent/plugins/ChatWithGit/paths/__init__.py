path_dict = {
    "query_git": "/git/query"
}