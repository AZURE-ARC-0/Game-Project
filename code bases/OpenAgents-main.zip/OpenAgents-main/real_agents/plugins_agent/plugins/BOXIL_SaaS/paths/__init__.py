path_dict = {
    "categories": "/api/v2/chatgpt_plugins/categories",
    "category_search": "/api/v2/chatgpt_plugins/category_search"
}