path_dict = {"search": "/api/rest/v1/search"}
