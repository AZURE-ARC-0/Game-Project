path_dict = {"score_hand_show": "/score_hand_show"}
