path_dict = {
    "search_products": "/search"
}