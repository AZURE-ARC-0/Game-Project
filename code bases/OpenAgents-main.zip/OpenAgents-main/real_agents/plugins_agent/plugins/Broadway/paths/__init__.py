path_dict = {"products": "/openai/v1/products"}
