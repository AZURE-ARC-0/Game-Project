path_dict = {"feedback": "/feedback", "upload_url": "/upload_url"}
