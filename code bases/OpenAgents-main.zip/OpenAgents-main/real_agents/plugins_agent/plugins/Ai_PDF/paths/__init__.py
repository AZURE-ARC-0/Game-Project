path_dict = {"summarize_pdf": "/summarize_pdf", "upload_and_search_pdf": "/upload_and_search_pdf"}
