from real_agents.adapters.data_model.plugin.spec import APIYamlModel, SpecModel
