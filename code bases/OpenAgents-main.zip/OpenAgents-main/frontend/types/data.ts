export interface KeyValuePair {
  key: string;
  value: any;
}
