from rdagent.components.coder.factor_coder.factor import FactorExperiment
from rdagent.core.experiment import Loader


class FactorExperimentLoader(Loader[FactorExperiment]):
    pass


class ModelExperimentLoader(Loader[FactorExperiment]):
    pass
