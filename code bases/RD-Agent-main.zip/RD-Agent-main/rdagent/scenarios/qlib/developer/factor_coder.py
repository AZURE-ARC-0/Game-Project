from rdagent.components.coder.factor_coder.CoSTEER import FactorCoSTEER

QlibFactorCoSTEER = FactorCoSTEER
# TODO: This is a placeholder. We need to split the scenario part of the task implementation into this folder
