
# Meta template
It is an example of how we organize the workspace of a competition.
We expect all the competitions to align with it so the knowledge in modules (model, feature) can transfer.

The generation process of the initial template is hoped to be conducted by LLM (however, it is based on human efforts currently).
