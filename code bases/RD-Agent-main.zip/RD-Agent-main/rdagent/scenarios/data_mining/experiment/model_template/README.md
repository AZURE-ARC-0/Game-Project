## This folder is a template to be copied from for each model implementation & running process. 

Components: Dummy model.py, versatile conf.yaml, and a result reader. 
