from rdagent.log.logger import RDAgentLog
from rdagent.log.utils import LogColors

rdagent_logger: RDAgentLog = RDAgentLog()
