"""
UI is a kind of view for user.

We are not sure how generality of the UI, we can't make decision among following options:
- in general folder like rdagent/log/ui
- It is for specific scenario rdagent/scenarios/
"""
