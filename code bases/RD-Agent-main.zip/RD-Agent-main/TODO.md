We encourage to set the TODOs in code. But some TODOs are more global.
So we place it here.


- [ ] Aligning the naming of files in components & scenarios.
  - We would like to have the same logic for naming convention in components(reusable components for all scenarios) and scenarios (componets for specific scenario).
  - But now we have following mismatch
    - `coder` in `components` & `developer` in `components`
- [ ] The name of the folders mismatch with the content in them.
  - Why are scenarios in experiments?
