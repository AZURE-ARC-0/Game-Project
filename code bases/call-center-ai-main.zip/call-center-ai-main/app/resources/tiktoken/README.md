# tiktoken cache

See:
- https://github.com/openai/tiktoken/blob/bfe00ad1bf59fac47513b45fe5173672dcbbcbb4/tiktoken/load.py#L35
- https://github.com/openai/tiktoken/blob/bfe00ad1bf59fac47513b45fe5173672dcbbcbb4/tiktoken_ext/openai_public.py#L91

## Files

| Encoder | Hash |
|-|-|
| o200k_base.tiktoken | fb374d419588a4632f3f557e76b4b70aebbca790 |
| cl100k_base.tiktoken | 9b5ad71b2ce5302211f9c61530b329a4922fc6a4 |
