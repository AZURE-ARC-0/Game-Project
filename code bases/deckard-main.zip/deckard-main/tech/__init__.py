TECH_ORDER = ["wooden", "stone", "iron", "golden", "diamond"]
