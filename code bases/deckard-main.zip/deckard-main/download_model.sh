mkdir -p models
mkdir -p weights

wget https://openaipublic.blob.core.windows.net/minecraft-rl/models/foundation-model-3x.model -O models/3x.model
wget https://openaipublic.blob.core.windows.net/minecraft-rl/models/bc-house-3x.weights -O weights/bc-house-3x.weights
