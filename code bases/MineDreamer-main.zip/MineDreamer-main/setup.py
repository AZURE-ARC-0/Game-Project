from setuptools import setup

# Basic setup.py file
setup(
    name='minedreamer',
    version='0.0.1',
    packages=['minedreamer'],
)

