(async (bot) => {

/* CODE HERE */
log(bot, 'Code finished.');

})