# .devcontainer

The files in this directory configure a VSCode environment like
GitHub codespaces.
