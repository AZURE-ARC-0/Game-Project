🔗 For more information on config files, visit [our documentation website][docs].

You can also find the corresponding markdown files in the [`docs/` folder][source].

[docs]: https://princeton-nlp.github.io/SWE-agent/config/config
[source]: https://github.com/princeton-nlp/SWE-agent/tree/main/docs
