# Flash

## Author
Budofsky
## Points
100
## Category
Forensics
## Description
We were able to grab an image of a harddrive. Find out what's on it.
## Flag
`flag{b3l0w_th3_r4dar}`
## Solution

## Setup
Distribute `flash_c8429a430278283c0e571baebca3d139.zip`