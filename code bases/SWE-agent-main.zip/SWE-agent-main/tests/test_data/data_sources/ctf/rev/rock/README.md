## Name
Rock

## Description
Never forget the people's champ.

## Points
100

## Solution
See [solution.cpp]()

## Flag
`FLAG{IoDJuvwxy\tuvyxwxvwzx{\z{vwxyz}`
