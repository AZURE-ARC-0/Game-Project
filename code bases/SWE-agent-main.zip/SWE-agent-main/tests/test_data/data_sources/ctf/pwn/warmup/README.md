## Name
WarmUp

## Description
So you want to be a pwn-er huh? Well let's throw you an easy one ;)

## Points
50

## Solution
See [warmup.py]()

## Flag
`FLAG{LET_US_BEGIN_CSAW_2016}`
