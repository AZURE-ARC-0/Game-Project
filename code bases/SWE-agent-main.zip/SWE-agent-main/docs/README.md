# Welcome to the SWE-agent docs

🔗 Simply want to read the docs? Please head to [the web version of these docs](https://princeton-nlp.github.io/SWE-agent/)

This folder holds the source for the SWE-agent documentation.
Want to modify and build the website locally? See [here](https://princeton-nlp.github.io/SWE-agent/dev/contribute#mkdocs).
