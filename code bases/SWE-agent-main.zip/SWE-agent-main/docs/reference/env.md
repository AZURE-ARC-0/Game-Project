# The environment class

::: sweagent.environment.swe_env
    options:
      allow_inspection: false