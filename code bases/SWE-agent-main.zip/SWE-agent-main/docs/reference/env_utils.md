# Environment utils

::: sweagent.environment.utils
    options:
      allow_inspection: false