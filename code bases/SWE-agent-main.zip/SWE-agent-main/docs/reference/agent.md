# The agent class

::: sweagent.agent.agents
    options:
      allow_inspection: false