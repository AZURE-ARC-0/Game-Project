<div class="grid cards" markdown>

-   :material-bug:{ .lg .middle } __Something broken?__
    [:octicons-arrow-right-24: Report bug](https://github.com/princeton-nlp/SWE-agent/issues/new?template=bug_report.yml)

-   :material-help:{ .lg .middle } __Something unclear?__
    [:octicons-arrow-right-24: Ask question](https://github.com/princeton-nlp/SWE-agent/issues/new?template=question.yml)

</div>
