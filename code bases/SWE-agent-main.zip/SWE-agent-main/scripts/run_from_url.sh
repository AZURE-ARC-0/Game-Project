python run.py \
    --model_name human \
    --data_path https://github.com/psf/requests/issues/6254 \
    --base_commit ac3be98b19f4d09c6a970b271a3ae30f3d0858f7 \
    --per_instance_cost_limit 3.00 \
    --config_file ./config/default_from_url.yaml
