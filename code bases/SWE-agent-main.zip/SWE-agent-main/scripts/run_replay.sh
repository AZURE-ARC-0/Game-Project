python run_replay.py \
  --traj_path ./trajectories/johnbyang/-demonstrations/pvlib__pvlib-python-1216.default_test.traj \
  --data_path ./trajectories/johnbyang/-demonstrations/pvlib__pvlib-python-1216.json \
  --config_file config/e2e/default_test.yaml