python run.py \
    --model_name human \
    --data_path ./data/dev-easy/swe-bench-dev-easy.json \
    --per_instance_cost_limit 3.00 \
    --config_file ./config/default.yaml
