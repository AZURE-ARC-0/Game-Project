#npm install
npm run watch
#npm run dev
#npm run build
