import Achievements from './achievements';

export default class AchievementsPlugin extends Phaser.Plugins.BasePlugin {
    add(): Achievements;

}