import Anchor from './behaviors/anchor/Anchor';
export default Anchor;