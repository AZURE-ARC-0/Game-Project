import LoaderCallback from './loader/awaitloader/AwaitLoaderCallback.js';

Phaser.Loader.FileTypesManager.register('rexAwait', LoaderCallback);

export default LoaderCallback;