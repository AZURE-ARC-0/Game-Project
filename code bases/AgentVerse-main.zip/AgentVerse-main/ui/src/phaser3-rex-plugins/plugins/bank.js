import Bank from './data/bank/Bank.js';
export default Bank;