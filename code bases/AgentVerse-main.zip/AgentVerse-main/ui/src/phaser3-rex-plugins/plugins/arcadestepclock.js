import ArcadeStepClock from './time/clock/ArcadeStepClock.js';
export default ArcadeStepClock;