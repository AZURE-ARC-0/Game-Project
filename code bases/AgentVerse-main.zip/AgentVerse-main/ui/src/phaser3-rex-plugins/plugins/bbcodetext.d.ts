import BBCodeText from './gameobjects/tagtext/bbcodetext/BBCodeText'
export default BBCodeText;