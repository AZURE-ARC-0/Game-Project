import AlphaMaskImage from './gameobjects/canvas/alphamaskimage/AlphaMaskImage.js';
export default AlphaMaskImage;