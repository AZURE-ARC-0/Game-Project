import AlphaMaskImage from './gameobjects/canvas/alphamaskimage/AlphaMaskImage';
export default AlphaMaskImage;