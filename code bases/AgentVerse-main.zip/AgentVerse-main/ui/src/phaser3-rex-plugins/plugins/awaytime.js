import AwayTime from './time/awaytime/AwayTime.js';
export default AwayTime;