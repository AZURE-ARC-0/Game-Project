import BitmapZone from './behaviors/bitmapzone/BitmapZone.js';
export default BitmapZone;