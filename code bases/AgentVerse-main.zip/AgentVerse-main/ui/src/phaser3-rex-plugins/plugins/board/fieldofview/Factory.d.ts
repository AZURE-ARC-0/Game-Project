import FieldOfView from './FieldOfView';

export default function (
    gameObject: Phaser.GameObjects.GameObject,
    config?: FieldOfView.IConfig
): FieldOfView;