var RectangleToTileXYArray = function (rectangle, testMode, out) {
    return this.shapeToTileXYArray(rectangle, testMode, out);
}

export default RectangleToTileXYArray;