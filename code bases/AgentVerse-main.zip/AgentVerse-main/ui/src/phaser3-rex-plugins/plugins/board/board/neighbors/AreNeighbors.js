var AreNeighbors = function(chessA, chessB) {
    return (this.getNeighborChessDirection(chessA, chessB) !== null);
}
export default AreNeighbors;