var TriangleToTileXYArray = function (triangle, testMode, out) {
    return this.shapeToTileXYArray(triangle, testMode, out);
}

export default TriangleToTileXYArray;