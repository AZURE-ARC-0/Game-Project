import Board from './Board';

export default function (
    config?: Board.IConfig
): Board;