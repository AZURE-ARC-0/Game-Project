var EllipseToTileXYArray = function (ellipse, testMode, out) {
    return this.shapeToTileXYArray(ellipse, testMode, out);
}

export default EllipseToTileXYArray;