var CircleToTileXYArray = function (circle, testMode, out) {
    return this.shapeToTileXYArray(circle, testMode, out);
}

export default CircleToTileXYArray;