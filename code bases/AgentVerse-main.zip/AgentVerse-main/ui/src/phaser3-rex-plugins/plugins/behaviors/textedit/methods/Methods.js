import Open from './Open.js';
import Close from './Close.js';

var Methods = {
    open: Open,
    close: Close,
};

export default Methods;