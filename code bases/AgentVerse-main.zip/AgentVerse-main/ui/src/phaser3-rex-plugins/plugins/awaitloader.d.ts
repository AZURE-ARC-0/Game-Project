import LoaderCallback from './loader/awaitloader/AwaitLoaderCallback.js';

export default LoaderCallback;