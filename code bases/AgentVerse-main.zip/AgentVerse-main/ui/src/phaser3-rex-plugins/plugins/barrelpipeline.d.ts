import BarrelPostFxPipeline from './shaders/barrel/BarrelPostFxPipeline';
export default BarrelPostFxPipeline;