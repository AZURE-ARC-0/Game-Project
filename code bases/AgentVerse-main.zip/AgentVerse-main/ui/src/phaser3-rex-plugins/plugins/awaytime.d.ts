import AwayTime from './time/awaytime/AwayTime';
export default AwayTime;