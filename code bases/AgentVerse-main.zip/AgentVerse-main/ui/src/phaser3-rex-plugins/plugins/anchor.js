import Anchor from './behaviors/anchor/Anchor.js';
export default Anchor;