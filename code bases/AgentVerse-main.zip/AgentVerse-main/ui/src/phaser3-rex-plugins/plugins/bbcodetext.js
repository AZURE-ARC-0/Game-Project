import BBCodeText from './gameobjects/tagtext/bbcodetext/BBCodeText.js'
export default BBCodeText;