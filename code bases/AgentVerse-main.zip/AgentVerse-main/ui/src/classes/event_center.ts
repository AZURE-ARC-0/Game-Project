import { Events } from "phaser";

const eventsCenter = new Events.EventEmitter();

export default eventsCenter;
