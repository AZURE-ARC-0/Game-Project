# Type Alias: Media

> **Media**: `object`

## Type declaration

### description

> **description**: `string`

### id

> **id**: `string`

### source

> **source**: `string`

### text

> **text**: `string`

### title

> **title**: `string`

### url

> **url**: `string`

## Defined in

[packages/core/src/types.ts:297](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/types.ts#L297)
