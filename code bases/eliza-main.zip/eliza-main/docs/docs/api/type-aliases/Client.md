# Type Alias: Client

> **Client**: `object`

## Type declaration

### start()

> **start**: (`runtime`?) => `Promise`\<`unknown`\>

#### Parameters

• **runtime?**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

#### Returns

`Promise`\<`unknown`\>

### stop()

> **stop**: (`runtime`?) => `Promise`\<`unknown`\>

#### Parameters

• **runtime?**: [`IAgentRuntime`](../interfaces/IAgentRuntime.md)

#### Returns

`Promise`\<`unknown`\>

## Defined in

[packages/core/src/types.ts:306](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/types.ts#L306)
