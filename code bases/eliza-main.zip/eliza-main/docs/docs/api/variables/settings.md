# Variable: settings

> `const` **settings**: `ProcessEnv`

## Defined in

[packages/core/src/settings.ts:54](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/settings.ts#L54)
