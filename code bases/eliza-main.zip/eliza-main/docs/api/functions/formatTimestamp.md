[@ai16z/eliza v1.0.0](../index.md) / formatTimestamp

# Function: formatTimestamp()

> **formatTimestamp**(`messageDate`): `string`

## Parameters

• **messageDate**: `number`

## Returns

`string`

## Defined in

[packages/core/src/messages.ts:94](https://github.com/ai16z/eliza/blob/main/packages/core/src/messages.ts#L94)
