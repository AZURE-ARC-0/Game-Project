[@ai16z/eliza v1.0.0](../index.md) / messageCompletionFooter

# Variable: messageCompletionFooter

> `const` **messageCompletionFooter**: "\nResponse format should be formatted in a JSON block like this:\n\`\`\`json\n\{ \"user\": \"\{\{agentName\}\}\", \"text\": string, \"action\": \"string\" \}\n\`\`\`"

## Defined in

[packages/core/src/parsing.ts:3](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L3)
