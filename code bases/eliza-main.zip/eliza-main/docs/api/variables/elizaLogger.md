[@ai16z/eliza v1.0.0](../index.md) / elizaLogger

# Variable: elizaLogger

> `const` **elizaLogger**: `ElizaLogger`

## Defined in

[packages/core/src/logger.ts:282](https://github.com/ai16z/eliza/blob/main/packages/core/src/logger.ts#L282)
