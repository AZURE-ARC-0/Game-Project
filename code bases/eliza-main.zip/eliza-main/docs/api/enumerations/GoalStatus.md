[@ai16z/eliza v1.0.0](../index.md) / GoalStatus

# Enumeration: GoalStatus

## Enumeration Members

### DONE

> **DONE**: `"DONE"`

#### Defined in

[packages/core/src/types.ts:57](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L57)

---

### FAILED

> **FAILED**: `"FAILED"`

#### Defined in

[packages/core/src/types.ts:58](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L58)

---

### IN_PROGRESS

> **IN_PROGRESS**: `"IN_PROGRESS"`

#### Defined in

[packages/core/src/types.ts:59](https://github.com/ai16z/eliza/blob/main/packages/core/src/types.ts#L59)
