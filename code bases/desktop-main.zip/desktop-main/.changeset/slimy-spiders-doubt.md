---
"@e2b/desktop-python": patch
"@e2b/desktop": patch
---

Create initial release
