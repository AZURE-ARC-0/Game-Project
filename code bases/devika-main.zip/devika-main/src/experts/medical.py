"""
PubMed archive RAG
"""