"""
Function calls and Parser for:
- SMILE Notation
- Molecule Parser

Visualization for:
- Molecule Structure
- Molecule Properties

Use RDKit bindings
"""