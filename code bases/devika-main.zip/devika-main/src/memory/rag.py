"""
Vector Search for Code Docs + Docs Loading
"""