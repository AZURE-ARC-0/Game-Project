// Copyright (c) Microsoft Corporation. All rights reserved.
// Program.cs

using AutoGen.SemanticKernel.Sample;

await Use_Kernel_Functions_With_Other_Agent.RunAsync();
