// Copyright (c) Microsoft Corporation. All rights reserved.
// Program.cs

using AutoGen.Gemini.Sample;

Image_Chat_With_Vertex_Gemini.RunAsync().Wait();
