# Backend Example

This example demonstrates how to create a simple backend service for the agent runtime using ASP.NET Core.

To Run it, simply run the following command in the terminal:

```bash
dotnet run
```

Or you can run it using Visual Studio Code by pressing `F5`.

