// Copyright (c) Microsoft Corporation. All rights reserved.
// IConnection.cs

namespace Microsoft.AutoGen.Abstractions;
public interface IConnection
{
}
