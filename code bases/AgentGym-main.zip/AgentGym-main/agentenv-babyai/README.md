# Agent Environments - BabyAI

## Setup

``` sh
conda create --name agentenv-babyai
conda activate agentenv-babyai
pip install -e .
```

## Launch

``` sh
babyai --host 0.0.0.0 --port 36001
```
