pip install alfworld
pip uninstall opencv-python -y
pip install -e .
export ALFWORLD_DATA=~/.cache/alfworld
alfworld-download
