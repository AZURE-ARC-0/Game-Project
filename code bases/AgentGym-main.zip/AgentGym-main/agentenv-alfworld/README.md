# Agent Environments - AlfWorld

## Setup

``` sh
conda create --name agentenv-alfworld python=3.9
conda activate agentenv-alfworld
bash ./setup.sh
```

## Launch

``` sh
alfworld --host 0.0.0.0 --port 36001
```
