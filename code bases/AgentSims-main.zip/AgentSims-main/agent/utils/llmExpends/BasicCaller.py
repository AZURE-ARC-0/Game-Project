from typing import List, Dict, Any

class BasicCaller:
    def __init__(self) -> None:
        pass
    
    async def ask(self, prompt: str) -> str:
        return prompt
