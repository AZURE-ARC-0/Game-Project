# from tests.config import TestMGPTConfig
#
# TEST_MEMGPT_CONFIG = TestMGPTConfig()
