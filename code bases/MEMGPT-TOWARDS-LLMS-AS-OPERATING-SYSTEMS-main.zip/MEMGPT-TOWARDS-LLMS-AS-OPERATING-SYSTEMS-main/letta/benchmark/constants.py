# Basic
TRIES = 3
AGENT_NAME = "benchmark"
PERSONA = "sam_pov"
HUMAN = "cs_phd"

# Prompts
PROMPTS = {
    "core_memory_replace": "Hey there, my name is John, what is yours?",
    "core_memory_append": "I want you to remember that I like soccers for later.",
    "conversation_search": "Do you remember when I talked about bananas?",
    "archival_memory_insert": "Can you make sure to remember that I like programming for me so you can look it up later?",
    "archival_memory_search": "Can you retrieve information about the war?",
}
