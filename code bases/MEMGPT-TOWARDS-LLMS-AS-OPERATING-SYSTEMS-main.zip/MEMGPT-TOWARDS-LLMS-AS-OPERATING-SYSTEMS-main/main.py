import typer

typer.secho(
    "Command `python main.py` no longer supported. Please run `letta run`. See https://docs.letta.com for more info.",
    fg=typer.colors.YELLOW,
)
