#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Desc   : MG Software Env


from metagpt.environment.base_env import Environment


class SoftwareEnv(Environment):
    """a specific alias name"""

    pass
