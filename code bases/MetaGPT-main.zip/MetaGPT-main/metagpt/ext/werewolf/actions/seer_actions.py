from metagpt.ext.werewolf.actions.common_actions import NighttimeWhispers


class Verify(NighttimeWhispers):
    name: str = "Verify"
