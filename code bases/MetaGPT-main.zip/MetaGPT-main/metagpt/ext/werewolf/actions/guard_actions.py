#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Desc   :

from metagpt.ext.werewolf.actions.common_actions import NighttimeWhispers


class Protect(NighttimeWhispers):
    name: str = "Protect"
