from metagpt.rag.benchmark.base import RAGBenchmark

__all__ = ["RAGBenchmark"]
