camel.memories.blocks package
=============================

Submodules
----------

camel.memories.blocks.chat\_history\_block module
-------------------------------------------------

.. automodule:: camel.memories.blocks.chat_history_block
   :members:
   :undoc-members:
   :show-inheritance:

camel.memories.blocks.vectordb\_block module
--------------------------------------------

.. automodule:: camel.memories.blocks.vectordb_block
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.memories.blocks
   :members:
   :undoc-members:
   :show-inheritance:
