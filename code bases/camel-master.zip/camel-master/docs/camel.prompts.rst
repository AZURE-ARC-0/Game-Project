camel.prompts package
=====================

Submodules
----------

camel.prompts.ai\_society module
--------------------------------

.. automodule:: camel.prompts.ai_society
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.base module
-------------------------

.. automodule:: camel.prompts.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.code module
-------------------------

.. automodule:: camel.prompts.code
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.evaluation module
-------------------------------

.. automodule:: camel.prompts.evaluation
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.generate\_text\_embedding\_data module
----------------------------------------------------

.. automodule:: camel.prompts.generate_text_embedding_data
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.image\_craft module
---------------------------------

.. automodule:: camel.prompts.image_craft
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.misalignment module
---------------------------------

.. automodule:: camel.prompts.misalignment
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.multi\_condition\_image\_craft module
---------------------------------------------------

.. automodule:: camel.prompts.multi_condition_image_craft
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.object\_recognition module
----------------------------------------

.. automodule:: camel.prompts.object_recognition
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.prompt\_templates module
--------------------------------------

.. automodule:: camel.prompts.prompt_templates
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.role\_description\_prompt\_template module
--------------------------------------------------------

.. automodule:: camel.prompts.role_description_prompt_template
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.solution\_extraction module
-----------------------------------------

.. automodule:: camel.prompts.solution_extraction
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.task\_prompt\_template module
-------------------------------------------

.. automodule:: camel.prompts.task_prompt_template
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.translation module
--------------------------------

.. automodule:: camel.prompts.translation
   :members:
   :undoc-members:
   :show-inheritance:

camel.prompts.video\_description\_prompt module
-----------------------------------------------

.. automodule:: camel.prompts.video_description_prompt
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.prompts
   :members:
   :undoc-members:
   :show-inheritance:
