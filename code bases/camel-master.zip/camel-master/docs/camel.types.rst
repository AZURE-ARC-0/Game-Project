camel.types package
===================

Submodules
----------

camel.types.enums module
------------------------

.. automodule:: camel.types.enums
   :members:
   :undoc-members:
   :show-inheritance:

camel.types.openai\_types module
--------------------------------

.. automodule:: camel.types.openai_types
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.types
   :members:
   :undoc-members:
   :show-inheritance:
