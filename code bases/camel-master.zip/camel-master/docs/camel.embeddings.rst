camel.embeddings package
========================

Submodules
----------

camel.embeddings.base module
----------------------------

.. automodule:: camel.embeddings.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.embeddings.mistral\_embedding module
------------------------------------------

.. automodule:: camel.embeddings.mistral_embedding
   :members:
   :undoc-members:
   :show-inheritance:

camel.embeddings.openai\_embedding module
-----------------------------------------

.. automodule:: camel.embeddings.openai_embedding
   :members:
   :undoc-members:
   :show-inheritance:

camel.embeddings.sentence\_transformers\_embeddings module
----------------------------------------------------------

.. automodule:: camel.embeddings.sentence_transformers_embeddings
   :members:
   :undoc-members:
   :show-inheritance:

camel.embeddings.vlm\_embedding module
--------------------------------------

.. automodule:: camel.embeddings.vlm_embedding
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.embeddings
   :members:
   :undoc-members:
   :show-inheritance:
