camel.retrievers package
========================

Submodules
----------

camel.retrievers.auto\_retriever module
---------------------------------------

.. automodule:: camel.retrievers.auto_retriever
   :members:
   :undoc-members:
   :show-inheritance:

camel.retrievers.base module
----------------------------

.. automodule:: camel.retrievers.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.retrievers.bm25\_retriever module
---------------------------------------

.. automodule:: camel.retrievers.bm25_retriever
   :members:
   :undoc-members:
   :show-inheritance:

camel.retrievers.cohere\_rerank\_retriever module
-------------------------------------------------

.. automodule:: camel.retrievers.cohere_rerank_retriever
   :members:
   :undoc-members:
   :show-inheritance:

camel.retrievers.vector\_retriever module
-----------------------------------------

.. automodule:: camel.retrievers.vector_retriever
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.retrievers
   :members:
   :undoc-members:
   :show-inheritance:
