camel.agents.tool\_agents package
=================================

Submodules
----------

camel.agents.tool\_agents.base module
-------------------------------------

.. automodule:: camel.agents.tool_agents.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.agents.tool\_agents.hugging\_face\_tool\_agent module
-----------------------------------------------------------

.. automodule:: camel.agents.tool_agents.hugging_face_tool_agent
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.agents.tool_agents
   :members:
   :undoc-members:
   :show-inheritance:
