camel.loaders package
=====================

Submodules
----------

camel.loaders.base\_io module
-----------------------------

.. automodule:: camel.loaders.base_io
   :members:
   :undoc-members:
   :show-inheritance:

camel.loaders.firecrawl\_reader module
--------------------------------------

.. automodule:: camel.loaders.firecrawl_reader
   :members:
   :undoc-members:
   :show-inheritance:

camel.loaders.jina\_url\_reader module
--------------------------------------

.. automodule:: camel.loaders.jina_url_reader
   :members:
   :undoc-members:
   :show-inheritance:

camel.loaders.unstructured\_io module
-------------------------------------

.. automodule:: camel.loaders.unstructured_io
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.loaders
   :members:
   :undoc-members:
   :show-inheritance:
