camel.toolkits package
======================

Submodules
----------

camel.toolkits.base module
--------------------------

.. automodule:: camel.toolkits.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.code\_execution module
-------------------------------------

.. automodule:: camel.toolkits.code_execution
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.dalle\_toolkit module
------------------------------------

.. automodule:: camel.toolkits.dalle_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.github\_toolkit module
-------------------------------------

.. automodule:: camel.toolkits.github_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.google\_maps\_toolkit module
-------------------------------------------

.. automodule:: camel.toolkits.google_maps_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.linkedin\_toolkit module
---------------------------------------

.. automodule:: camel.toolkits.linkedin_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.math\_toolkit module
-----------------------------------

.. automodule:: camel.toolkits.math_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.open\_api\_toolkit module
----------------------------------------

.. automodule:: camel.toolkits.open_api_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.openai\_function module
--------------------------------------

.. automodule:: camel.toolkits.function_tool
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.reddit\_toolkit module
-------------------------------------

.. automodule:: camel.toolkits.reddit_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.retrieval\_toolkit module
----------------------------------------

.. automodule:: camel.toolkits.retrieval_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.search\_toolkit module
-------------------------------------

.. automodule:: camel.toolkits.search_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.slack\_toolkit module
------------------------------------

.. automodule:: camel.toolkits.slack_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.twitter\_toolkit module
--------------------------------------

.. automodule:: camel.toolkits.twitter_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

camel.toolkits.weather\_toolkit module
--------------------------------------

.. automodule:: camel.toolkits.weather_toolkit
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.toolkits
   :members:
   :undoc-members:
   :show-inheritance:
