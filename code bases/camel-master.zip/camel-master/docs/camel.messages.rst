camel.messages package
======================

Submodules
----------

camel.messages.base module
--------------------------

.. automodule:: camel.messages.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.messages.func\_message module
-----------------------------------

.. automodule:: camel.messages.func_message
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.messages
   :members:
   :undoc-members:
   :show-inheritance:
