camel.tasks package
===================

Submodules
----------

camel.tasks.task module
-----------------------

.. automodule:: camel.tasks.task
   :members:
   :undoc-members:
   :show-inheritance:

camel.tasks.task\_prompt module
-------------------------------

.. automodule:: camel.tasks.task_prompt
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.tasks
   :members:
   :undoc-members:
   :show-inheritance:
