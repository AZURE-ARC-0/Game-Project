camel.societies package
=======================

Submodules
----------

camel.societies.babyagi\_playing module
---------------------------------------

.. automodule:: camel.societies.babyagi_playing
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.role\_playing module
------------------------------------

.. automodule:: camel.societies.role_playing
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   camel.societies.workforce

Module contents
---------------

.. automodule:: camel.societies
   :members:
   :undoc-members:
   :show-inheritance:
