camel.configs package
=====================

Submodules
----------

camel.configs.anthropic\_config module
--------------------------------------

.. automodule:: camel.configs.anthropic_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.base\_config module
---------------------------------

.. automodule:: camel.configs.base_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.gemini\_config module
-----------------------------------

.. automodule:: camel.configs.gemini_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.groq\_config module
---------------------------------

.. automodule:: camel.configs.groq_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.litellm\_config module
------------------------------------

.. automodule:: camel.configs.litellm_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.mistral\_config module
------------------------------------

.. automodule:: camel.configs.mistral_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.ollama\_config module
-----------------------------------

.. automodule:: camel.configs.ollama_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.openai\_config module
-----------------------------------

.. automodule:: camel.configs.openai_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.reka\_config module
---------------------------------

.. automodule:: camel.configs.reka_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.samba\_config module
----------------------------------

.. automodule:: camel.configs.samba_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.togetherai\_config module
---------------------------------------

.. automodule:: camel.configs.togetherai_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.vllm\_config module
---------------------------------

.. automodule:: camel.configs.vllm_config
   :members:
   :undoc-members:
   :show-inheritance:

camel.configs.zhipuai\_config module
------------------------------------

.. automodule:: camel.configs.zhipuai_config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.configs
   :members:
   :undoc-members:
   :show-inheritance:
