camel.societies.workforce package
=======================

Submodules
----------

camel.societies.workforce.base module
---------------------------

.. automodule:: camel.societies.workforce.base
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.prompts module
---------------------------

.. automodule:: camel.societies.workforce.prompts
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.role\_playing\_worker module
------------------------------------

.. automodule:: camel.societies.workforce.role_playing_worker
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.single\_agent\_worker module
------------------------------------------

.. automodule:: camel.societies.workforce.single_agent_worker
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.task\_channel module
------------------------------------------

.. automodule:: camel.societies.workforce.task_channel
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.utils module
----------------------------

.. automodule:: camel.societies.workforce.utils
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.worker module
-----------------------------------

.. automodule:: camel.societies.workforce.worker
   :members:
   :undoc-members:
   :show-inheritance:

camel.societies.workforce.workforce module
--------------------------------

.. automodule:: camel.societies.workforce.workforce
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: camel.societies.workforce
   :members:
   :undoc-members:
   :show-inheritance:
