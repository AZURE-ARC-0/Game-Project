# Agent-Computer Interface (ACI) for OpenHands

An Agent-Computer Interface (ACI) designed for software development agents [OpenHands](https://github.com/All-Hands-AI/OpenHands).
