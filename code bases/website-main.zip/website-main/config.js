export const config = {
    owner: 'ai16z',
    repo: 'eliza',
    token: null // We'll handle authentication through the server instead
}; 