from jarvis.assembly.scripts.craft_agent import Worker as CraftScript
from jarvis.assembly.scripts.equip_agent import WorkerPlus as EquipScript
from jarvis.assembly.scripts.smelt_agent import Worker_smelting as SmeltScript