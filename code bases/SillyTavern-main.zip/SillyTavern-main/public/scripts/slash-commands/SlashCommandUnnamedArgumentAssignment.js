import { SlashCommandClosure } from './SlashCommandClosure.js';

export class SlashCommandUnnamedArgumentAssignment {
    /**@type {number}*/ start;
    /**@type {number}*/ end;
    /**@type {string|SlashCommandClosure}*/ value;


    constructor() {
    }
}
