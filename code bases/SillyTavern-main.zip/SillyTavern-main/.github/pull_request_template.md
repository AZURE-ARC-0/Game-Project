<!-- Put X in the box below to confirm -->

## Checklist:

- [ ] I have read the [Contributing guidelines](https://github.com/SillyTavern/SillyTavern/blob/release/CONTRIBUTING.md).
