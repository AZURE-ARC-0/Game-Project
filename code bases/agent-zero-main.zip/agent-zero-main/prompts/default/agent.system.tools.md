## Tools available:

{{ include './agent.system.tool.response.md' }}

{{ include './agent.system.tool.call_sub.md' }}

{{ include './agent.system.tool.knowledge.md' }}

{{ include './agent.system.tool.memory.md' }}

{{ include './agent.system.tool.code_exe.md' }}

{{ include './agent.system.tool.web.md' }}