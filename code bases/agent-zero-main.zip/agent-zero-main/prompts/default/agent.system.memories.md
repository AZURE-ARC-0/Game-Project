# Memories on the topic
- following are your memories about current topic:

{{memories}}