~~~json
{
    "system_warning": "No output or error was returned. If you require output from the tool, you have to use use console printing in your code. Otherwise proceed."
}
~~~