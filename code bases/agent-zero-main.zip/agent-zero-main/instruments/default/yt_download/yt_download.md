# Problem
Download a YouTube video
# Solution
1. If folder is specified, cd to it
2. Run instrument "bash /instruments/default/yt_download/yt_download.sh <url>" with your video URL
3. Wait for the terminal to finish